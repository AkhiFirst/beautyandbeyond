<?php 
	if (is_active_sidebar( 'front-page-top-widget-area' ) ){
		dynamic_sidebar( 'front-page-top-widget-area' );
	}
?>