<?php 
	if (is_active_sidebar( 'front-page-products-widget-area') ){
		dynamic_sidebar( 'front-page-products-widget-area');
	}
?>